from http import HTTPStatus
from typing import Dict, Text

import rasax.community.config as rasa_x_config
import rasax.community.utils.io as io_utils
import rasax.community.utils.cli as cli_utils
import rasax.community.utils.common as common_utils
from rasax.community.api.decorators import (
    rasa_x_scoped,
    inject_rasa_x_user,
    validate_schema,
)
from rasax.community.services.domain_service import DomainService
import rasax.community.constants as constants
from sanic import Blueprint, response
from sanic.request import Request
from sanic.response import HTTPResponse

from rasa.shared.core.domain import InvalidDomain
from rasa.shared.exceptions import YamlException

ID_KEY = "id"
FILENAME_KEY = "filename"
CONTENT_YAML_KEY = "content_yaml"


def blueprint() -> Blueprint:
    """Declare endpoints for all domain related actions.

    Returns:
        Sanic Blueprint collection.
    """
    domain_endpoints = Blueprint("domain_endpoints")

    @domain_endpoints.route("/domain", methods=["GET", "HEAD"])
    @rasa_x_scoped("domain.get", allow_api_token=True)
    async def get_domain(request: Request) -> HTTPResponse:
        cli_utils.raise_warning(
            'The endpoint "GET /domain" is deprecated, please use '
            '"GET /projects/<project_id>/domains" instead.',
            category=FutureWarning,
        )

        domain_service = DomainService.from_request(request)
        domain = domain_service.get_merged_domain(rasa_x_config.project_name)
        if domain is None:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "DomainNotFound", "Could not find domain."
            )

        domain_service.remove_domain_edited_states(domain)
        return response.text(domain_service.dump_cleaned_domain_yaml(domain))

    @domain_endpoints.route("/domain", methods=["PUT"])
    @rasa_x_scoped("domain.update", allow_api_token=True)
    @inject_rasa_x_user()
    async def put_domain(request: Request, user: Dict) -> HTTPResponse:
        cli_utils.raise_warning(
            'The endpoint "PUT /domain" is deprecated, please use '
            '"PUT /projects/<project_id>/domains/<id>" instead.',
            category=FutureWarning,
        )

        common_utils.handle_deprecated_request_parameters(
            request, "store_templates", "store_responses"
        )
        store_responses = common_utils.bool_arg(request, "store_responses", False)
        domain_yaml = io_utils.convert_bytes_to_string(request.body)
        try:
            updated_domain = DomainService.from_request(
                request
            ).validate_and_store_domain_yaml(
                domain_yaml,
                project_id=rasa_x_config.project_name,
                username=user[constants.USERNAME_KEY],
                store_responses=store_responses,
                overwrite=True,
            )
        except InvalidDomain as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST,
                "InvalidDomainError",
                "Could not update domain.",
                e,
            )

        return response.text(updated_domain)

    @domain_endpoints.route("/domainWarnings", methods=["GET", "HEAD"])
    @rasa_x_scoped("domainWarnings.get")
    async def get_domain_warnings(request: Request) -> HTTPResponse:
        domain_service = DomainService.from_request(request)
        domain_warnings = await domain_service.get_domain_warnings(
            rasa_x_config.project_name
        )
        if domain_warnings is None:
            return common_utils.error(
                HTTPStatus.NOT_FOUND, "DomainNotFound", "Could not find domain."
            )

        return response.json(
            domain_warnings[0], headers={"X-Total-Count": domain_warnings[1]}
        )

    @domain_endpoints.route("/projects/<project_id>/domains", methods=["GET", "HEAD"])
    @rasa_x_scoped("domain.get", allow_api_token=True)
    async def get_domains(request: Request, project_id: Text) -> HTTPResponse:
        """Get all domains from the project with their corresponding names.

        Args:
            request: The incoming request.
            project_id: ID of the project.

        Returns:
            JSON string with existing domains.
        """
        domain_service = DomainService.from_request(request)
        domains = [
            {ID_KEY: d.id, FILENAME_KEY: d.filename, CONTENT_YAML_KEY: d.as_dict()}
            for d in domain_service.get_all_domains_from_project(project_id)
        ]

        for domain in domains:

            domain[FILENAME_KEY] = domain[FILENAME_KEY].replace(
                f"{str(io_utils.get_project_directory().resolve())}/", ""
            )
            domain_service.remove_domain_edited_states(domain[CONTENT_YAML_KEY])
            domain[CONTENT_YAML_KEY] = domain_service.dump_cleaned_domain_yaml(
                domain[CONTENT_YAML_KEY]
            )

        return response.json(domains)

    @domain_endpoints.route("/projects/<project_id>/domains", methods=["POST"])
    @rasa_x_scoped("domain.create", allow_api_token=True)
    @inject_rasa_x_user()
    @validate_schema("domain")
    async def post_domains(
        request: Request, user: Dict, project_id: Text
    ) -> HTTPResponse:
        """Creates domain file.

        Args:
            request: The incoming request.
            user: Name of the user who performs the action.
            project_id: ID of the project.

        Returns:
            HTTP response with the updated domain file.
        """
        store_responses = common_utils.bool_arg(request, "store_responses", False)
        filename = request.json.get(FILENAME_KEY, "")
        content_yaml = io_utils.convert_bytes_to_string(
            request.json.get(CONTENT_YAML_KEY, "")
        )

        try:
            domain_id, created_domain = DomainService.from_request(
                request
            ).validate_and_store_domain_yaml(
                content_yaml,
                project_id=project_id,
                username=user[constants.USERNAME_KEY],
                filename=filename,
                store_responses=store_responses,
            )
        except (InvalidDomain, YamlException) as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST,
                "InvalidDomainError",
                "Could not create domain.",
                e,
            )
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.CONFLICT,
                "DomainExistsError",
                "Domain file already exists.",
                e,
            )

        return response.json(
            {
                ID_KEY: domain_id,
                FILENAME_KEY: filename,
                CONTENT_YAML_KEY: created_domain,
            }
        )

    @domain_endpoints.route(
        "/projects/<project_id>/domains/<domain_id:int>", methods=["PUT"]
    )
    @rasa_x_scoped("domain.update", allow_api_token=True)
    @inject_rasa_x_user()
    @validate_schema("domain")
    async def put_domains(
        request: Request, user: Dict, project_id: Text, domain_id: int
    ) -> HTTPResponse:
        """Update domain file with a specified `ID`.

        Args:
            request: The incoming request.
            user: Name of the user who performs the action.
            project_id: ID of the project.
            domain_id: ID of the target domain file to update.

        Returns:
            HTTP response with updated domain file.
        """
        store_responses = common_utils.bool_arg(request, "store_responses", False)
        filename = request.json.get(FILENAME_KEY, "")
        content_yaml = io_utils.convert_bytes_to_string(
            request.json.get(CONTENT_YAML_KEY, "")
        )

        try:
            _, updated_domain = DomainService.from_request(
                request
            ).validate_and_store_domain_yaml(
                content_yaml,
                project_id=project_id,
                domain_id=domain_id,
                username=user[constants.USERNAME_KEY],
                filename=filename,
                store_responses=store_responses,
                overwrite=True,
            )
        except (InvalidDomain, YamlException) as e:
            return common_utils.error(
                HTTPStatus.BAD_REQUEST,
                "InvalidDomainError",
                "Could not update domain.",
                e,
            )
        except ValueError as e:
            return common_utils.error(
                HTTPStatus.NOT_FOUND,
                "DomainNotFoundError",
                "Could not find domain.",
                e,
            )

        return response.json({FILENAME_KEY: filename, CONTENT_YAML_KEY: updated_domain})

    @domain_endpoints.route(
        "/projects/<project_id>/domains/<domain_id:int>", methods=["DELETE"]
    )
    @rasa_x_scoped("domain.delete", allow_api_token=True)
    async def delete_domain(
        request: Request, project_id: Text, domain_id: int
    ) -> HTTPResponse:
        """Delete domain with a specified `ID`.

        Args:
            request: The incoming HTTP request.
            project_id: ID of the project. Currently not used, since `domain_id` already
                uniquely identifies the domain.
            domain_id: ID of the target domain file to delete.

        Returns:
            HTTP response.
        """
        was_deleted = DomainService.from_request(request).delete_domain(domain_id)
        if was_deleted:
            return response.text("Domain was deleted", HTTPStatus.NO_CONTENT)

        return common_utils.error(
            HTTPStatus.NOT_FOUND, "DomainNotFoundError", "Could not find domain."
        )

    return domain_endpoints
