"""Change domain_slot `value` and `initial_value` to variabale-size columns.

Reason:
The `values` list of a categorical slot could be arbitrarily long, and an `inital_value`
could contain anything, including long lists and large JSON objects.
We do not want to restrict the size of these columns.

Revision ID: 052172fdb4b3
Revises: d9156a63aa00

"""
import sqlalchemy as sa
import logging

import rasax.community.database.schema_migrations.alembic.utils as migration_utils


logger = logging.getLogger(__name__)


# revision identifiers, used by Alembic.
revision = "052172fdb4b3"
down_revision = "d9156a63aa00"
branch_labels = None
depends_on = None

TABLE_NAME = "domain_slot"
COLUMNS_TO_MIGRATE = ["initial_value", "values"]


def upgrade():
    target_type = sa.Text()

    modifications = []
    for column in COLUMNS_TO_MIGRATE:
        modifications.append(
            migration_utils.ColumnTransformation(
                column, [target_type], {"nullable": True}
            )
        )

    migration_utils.modify_columns(TABLE_NAME, modifications)


def downgrade():
    target_type = sa.String(255)

    modifications = []
    for column in COLUMNS_TO_MIGRATE:
        modifications.append(
            migration_utils.ColumnTransformation(
                column, [target_type], {"nullable": True}
            )
        )

    migration_utils.modify_columns(TABLE_NAME, modifications)
