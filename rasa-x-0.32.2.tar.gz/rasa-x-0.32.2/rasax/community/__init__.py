from rasax.community import version

__version__ = version.__version__

del version
