self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8fd1d418879adbc1c17a025518a69640",
    "url": "/index.html"
  },
  {
    "revision": "eff79d32f9974e7fffa3",
    "url": "/static/css/2.9c49e7ce.chunk.css"
  },
  {
    "revision": "eff79d32f9974e7fffa3",
    "url": "/static/js/2.deb47126.chunk.js"
  },
  {
    "revision": "c183517d52b6af236b736ea339c09d67",
    "url": "/static/js/2.deb47126.chunk.js.LICENSE.txt"
  },
  {
    "revision": "251fff3fc160398bde76",
    "url": "/static/js/3.7bedfaee.chunk.js"
  },
  {
    "revision": "a449235a0e9017a44d2ecf71739168df",
    "url": "/static/js/3.7bedfaee.chunk.js.LICENSE.txt"
  },
  {
    "revision": "75015fbe2a2f3cb3918d",
    "url": "/static/js/4.069d2825.chunk.js"
  },
  {
    "revision": "6efc163e543d30445b96",
    "url": "/static/js/5.09a81aaf.chunk.js"
  },
  {
    "revision": "1248d33ec7dca411ce1c",
    "url": "/static/js/6.80729e91.chunk.js"
  },
  {
    "revision": "78ba0af0338ba2ed8582",
    "url": "/static/js/main.d2fb9ef5.chunk.js"
  },
  {
    "revision": "f0ec5577fef3d032417a",
    "url": "/static/js/runtime-main.5cc59ce2.js"
  },
  {
    "revision": "634e5dc019fcbee7676792431bd4e870",
    "url": "/static/media/chat_placeholder.634e5dc0.svg"
  },
  {
    "revision": "6ff85daeb23dea6775085805ef9f6d64",
    "url": "/static/media/conversations_placeholder.6ff85dae.svg"
  },
  {
    "revision": "3e303cf2f7d3723be613f8ac69c42d95",
    "url": "/static/media/filters_placeholder.3e303cf2.svg"
  },
  {
    "revision": "af83e9dbb636a909291e5ee6600fe715",
    "url": "/static/media/models_placeholder.af83e9db.svg"
  },
  {
    "revision": "23a1172ebcb0dcbe0068732ffcd702ce",
    "url": "/static/media/nlu_training_placeholder.23a1172e.svg"
  },
  {
    "revision": "23a7393c55a54f2e9d1f63691e04eef3",
    "url": "/static/media/rasa_horizontal_logo.23a7393c.svg"
  },
  {
    "revision": "bf7620f2ca73a1bc1e1e272efda10e79",
    "url": "/static/media/rasa_horizontal_logo_white.bf7620f2.svg"
  }
]);