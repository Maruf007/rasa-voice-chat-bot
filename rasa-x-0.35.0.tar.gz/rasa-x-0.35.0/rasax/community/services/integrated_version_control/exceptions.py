class GitError(Exception):
    """Base exception for all Git errors."""


class GitConcurrentOperationException(GitError):
    """Exception that is raised when there's another Git operation in progress."""


class GitCommitError(GitError):
    """Exception in case an error happens when trying to push changes."""


class GitBranchError(GitError):
    """Exception in case an error happens when trying to create a new branch."""


class CredentialsError(GitError):
    """Exception raised in case there are no read and write permissions for the Git repository."""


class GitHTTPSCredentialsError(CredentialsError):
    """Exception raised in case an error occurred when trying to fetch or push
    from a remote repository, due to invalid credentials being specified for
    an HTTPS connection."""


class ProjectLayoutError(GitError):
    """Exception if the connected repository doesn't have the required layout.

    Raised if domain, config or data directory don't exist.
    """
