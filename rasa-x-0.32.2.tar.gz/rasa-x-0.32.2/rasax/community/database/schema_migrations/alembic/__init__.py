import os

ALEMBIC_DIR = os.path.dirname(__file__)
